﻿export class Global {
    public static BASE_USER_ENDPOINT = 'api/userapi/';
}